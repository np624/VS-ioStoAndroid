package com.example.iostoandroidapplication.enums;

public enum ImagePickerEnum {
    FROM_GALLERY,
    FROM_CAMERA
}
